﻿using UnityEngine;
using System.Collections;
[RequireComponent(typeof(AudioSource))]

public class Sounds : MonoBehaviour {
	public AudioClip stoneskipping;
	public AudioClip rockhitleave;
	public AudioClip snore;
	public AudioClip fish;
	public AudioClip spash;
	public AudioClip lake;
	public AudioClip frog;
	public AudioClip wave;
	public AudioClip duck;
	public AudioClip waterdrop;
	public AudioClip grabstone;
	public AudioClip hitfish;
	public AudioClip stone;
	public AudioClip bird;
	public AudioClip paddle;
	public AudioClip rope;
	public AudioClip star;
	public AudioClip glow;
	public AudioClip paddlewrong;
	public AudioClip rain;
	public AudioClip win;
	public AudioClip flower;
	public AudioClip leave;
	public AudioClip wind;
	public AudioClip brake;
	public AudioClip grass;
	public AudioClip footstep;
	public AudioClip boat;
	public AudioClip crickets;
	public AudioClip sky;
	public AudioClip lightning;
	public AudioClip shiny;
	public AudioClip lakewaveslapping;
	public AudioClip  fishploppy;
	public AudioClip  wingflpping;
	public AudioClip landonflpping;
	public AudioClip panicflapping;
	public AudioClip weakflapping;
	public AudioClip struggleflapping;
	public AudioClip shortflapping;
	public AudioClip smallflapping;
	public AudioClip seedpouring;
	public AudioClip grabseed;
	public AudioClip birdflyslonghand;
	public AudioClip birdonboat;
	public AudioClip birdlandonboat;
	public AudioClip birdstandonpaddle;
	public AudioClip birdpecking;
	public AudioClip panicfrog;
	public AudioClip panicbird;
	public AudioClip grabbird;
	public AudioClip boatshake;
	public AudioClip boatshake1;
	public AudioClip boatshiffer;
	public AudioClip boatshiffer1;
	public AudioClip boatshiffer2;

	public AudioClip longcreak;
	public AudioClip longlean;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
